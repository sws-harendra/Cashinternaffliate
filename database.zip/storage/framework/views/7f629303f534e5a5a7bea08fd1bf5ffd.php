

<?php $__env->startPush('title'); ?>
<title>Add Training Video | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>

<div class="pcoded-content">

    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">

                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Add Training Video</h5>
                        <p class="m-b-0">Add a new training video inside a subcategory</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.dashboard')); ?>"> <i class="fa fa-home"></i> </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.training-videos.index')); ?>">Training Videos</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">Add</a></li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header">
                        <h5>Add New Video</h5>
                    </div>

                    <div class="card-block">

                        <form method="POST" action="<?php echo e(route('admins.training-videos.store')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label>Sub Category *</label>
                                <select name="sub_category_id" class="form-control" required>
                                    <option value="">Select Sub Category</option>
                                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Video Title *</label>
                                <input type="text" name="title" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" class="form-control"></textarea>
                            </div>

                            <div class="form-group">
                                <label>Video URL *</label>
                                <input type="text" name="video_url" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label>Duration (seconds)</label>
                                <input type="number" name="duration" class="form-control">
                            </div>

                            <div class="form-group">
                                <label>Status *</label>
                                <select name="status" class="form-control">
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>

                            <button class="btn btn-primary">Save Video</button>

                        </form>

                    </div>
                </div>

            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/training_videos/create.blade.php ENDPATH**/ ?>