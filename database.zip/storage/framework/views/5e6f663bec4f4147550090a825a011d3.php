

<?php $__env->startPush('title'); ?>
<title>Training Videos | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

    <!-- Header -->
    <div class="page-header">
        <div class="page-block">
            <h5 class="m-b-10">Training Videos</h5>
            <p class="m-b-0">Manage all training videos</p>
        </div>
    </div>

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header">
                        <h5>Videos List</h5>
                        <a href="<?php echo e(route('admins.training-videos.create')); ?>" 
                           class="btn btn-primary btn-sm float-right">Add New</a>
                    </div>

                    <div class="card-block">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>Category</th>
                                        <th>Video URL</th>
                                        <th>Duration</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i + 1); ?></td>
                                        <td><?php echo e($v->title); ?></td>
                                        <td><?php echo e($v->subcategory->name ?? 'N/A'); ?></td>
                                        <td><a href="<?php echo e($v->video_url); ?>" target="_blank">Open</a></td>
                                        <td><?php echo e($v->duration ? $v->duration.' sec' : '—'); ?></td>

                                        <td>
                                            <?php if($v->status): ?>
                                                <span class="badge badge-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger">Inactive</span>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <a href="<?php echo e(route('admins.training-videos.edit', $v->id)); ?>" 
                                               class="btn btn-warning btn-sm">Edit</a>

                                            <a onclick="return confirm('Delete this video?')" 
                                               href="<?php echo e(route('admins.training-videos.delete', $v->id)); ?>"
                                               class="btn btn-danger btn-sm">Delete</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>

                        <?php echo e($videos->links()); ?>


                    </div>
                </div>

            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/training_videos/index.blade.php ENDPATH**/ ?>