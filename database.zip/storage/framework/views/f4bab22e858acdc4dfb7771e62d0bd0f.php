

<?php $__env->startPush('title'); ?>
    <title>Verify Recruiter | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Recruiter Verification</h5>
                        <p class="m-b-0">Review recruiter document</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.dashboard')); ?>">
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.recruiter.verifications')); ?>">
                                Recruiter Verifications
                            </a>
                        </li>
                        <li class="breadcrumb-item">Details</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <?php echo $__env->make('backend.admins.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="card">
        <div class="card-header">
            <h5>Recruiter Details</h5>
        </div>

        <div class="card-block">
            <p><strong>Name:</strong> <?php echo e($verification->recruiter->name); ?></p>
            <p><strong>Email:</strong> <?php echo e($verification->recruiter->email); ?></p>
            <p><strong>Document Type:</strong> <?php echo e($verification->document_type); ?></p>

            <p>
                <strong>Uploaded Document:</strong><br>
                <a href="<?php echo e(asset( $verification->document_file)); ?>"
                   target="_blank"
                   class="btn btn-sm btn-info">
                    View Document
                </a>
            </p>

            <hr>

            <?php if($verification->status === 'pending'): ?>

                <form method="POST"
                      action="<?php echo e(route('admins.recruiter.verifications.approve', $verification->id)); ?>"
                      class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-success">
                        Approve
                    </button>
                </form>

                <button class="btn btn-danger"
                        data-toggle="modal"
                        data-target="#rejectModal">
                    Reject
                </button>

            <?php else: ?>
                <span class="badge badge-info">
                    Already <?php echo e(ucfirst($verification->status)); ?>

                </span>
            <?php endif; ?>
        </div>
    </div>

</div>


<div class="modal fade" id="rejectModal">
    <div class="modal-dialog">
        <form method="POST"
              action="<?php echo e(route('admins.recruiter.verifications.reject', $verification->id)); ?>">
            <?php echo csrf_field(); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Reject Verification</h5>
                </div>

                <div class="modal-body">
                    <textarea name="admin_remark"
                              class="form-control"
                              placeholder="Reason for rejection"
                              required></textarea>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-secondary" data-dismiss="modal">
                        Cancel
                    </button>
                    <button class="btn btn-danger">
                        Reject
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/recruiter_verifications/show.blade.php ENDPATH**/ ?>