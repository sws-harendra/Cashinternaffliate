

<?php $__env->startPush('title'); ?>
    <title>Admin Dashboard | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="pcoded-content">
        <!-- Page-header start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Dashboard</h5>
                            <p class="m-b-0">Welcome to <?php echo e(env('APP_NAME')); ?> Admin Dashboard</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item">
                                <a href="index.html"> <i class="fa fa-home"></i> </a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page-header end -->
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/dashboard.blade.php ENDPATH**/ ?>