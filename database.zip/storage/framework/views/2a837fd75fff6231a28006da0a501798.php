

<?php $__env->startPush('title'); ?>
    <title>Recruiter Profile | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="pcoded-content">

        <!-- Page Header -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Company Profile</h5>
                            <p class="m-b-0">Complete your company details</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('recruiters.dashboard')); ?>">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">Profile</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Alerts -->
        <?php echo $__env->make('backend.recruiters.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Profile Card -->
        <div class="card">
            <div class="card-header">
                <h5>Company Information</h5>
            </div>

            <div class="card-block">
                <form method="POST" action="<?php echo e(route('recruiters.profile.update')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    
                    <div class="form-group">
                        <label>Company Logo</label><br>

                        <?php if($profile && $profile->logo): ?>
                            <img src="<?php echo e(asset($profile->logo)); ?>" class="img-radius mb-2" style="height:80px;">
                        <?php endif; ?>

                        <input type="file" name="logo" class="form-control">
                        <small class="text-muted">JPG / PNG (Max 2MB)</small>
                    </div>

                    <div class="form-group">
                        <label>Company Description</label>
                        <textarea name="company_description" class="form-control" rows="4" required><?php echo e($profile->company_description ?? ''); ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <label>Industry</label>
                            <input type="text" name="industry" class="form-control"
                                value="<?php echo e($profile->industry ?? ''); ?>">
                        </div>

                        <div class="col-md-6">
                            <label>Company Size</label>
                            <input type="text" name="company_size" class="form-control" placeholder="1-10 / 10-50 / 50+"
                                value="<?php echo e($profile->company_size ?? ''); ?>">
                        </div>
                    </div>

                    <div class="form-group mt-2">
                        <label>Company Address</label>
                        <input type="text" name="address" class="form-control" value="<?php echo e($profile->address ?? ''); ?>">
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <label>HR Name</label>
                            <input type="text" name="hr_name" class="form-control" value="<?php echo e($profile->hr_name ?? ''); ?>">
                        </div>

                        <div class="col-md-6">
                            <label>HR Contact</label>
                            <input type="text" name="hr_contact" class="form-control"
                                value="<?php echo e($profile->hr_contact ?? ''); ?>">
                        </div>
                    </div>
                    <div class="form-group mt-2">
                        <label>Company Website</label>
                        <input type="url" name="website" class="form-control" placeholder="https://www.example.com"
                            value="<?php echo e($profile->website ?? ''); ?>">
                    </div>


                    <div class="mt-4">
                        <button class="btn btn-primary">
                            Save Profile
                        </button>
                    </div>

                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.recruiters.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/recruiters/pages/profile.blade.php ENDPATH**/ ?>