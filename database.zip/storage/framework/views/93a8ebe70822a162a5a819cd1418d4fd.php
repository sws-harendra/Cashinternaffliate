

<?php $__env->startPush('title'); ?>
    <title>Edit Affiliate Product | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="pcoded-content">

        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">

                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Edit Affiliate Product</h5>
                            <p>Edit product details</p>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('admins.dashboard')); ?>"> <i class="fa fa-home"></i> </a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Edit Product</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>

        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="card">
                        <div class="card-header">
                            <h5>Edit Product</h5>
                        </div>

                        <div class="card-block">

                            <form method="POST" action="<?php echo e(route('admins.affiliate-products.update', $product->id)); ?>"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="row">

                                    <div class="col-md-6">
                                        <label>Title *</label>
                                        <input type="text" name="title" id="title" value="<?php echo e($product->title); ?>"
                                            class="form-control" required>
                                    </div>

                                    <div class="col-md-6">
                                        <label>Slug *</label>
                                        <input type="text" name="slug" id="slug" value="<?php echo e($product->slug); ?>"
                                            class="form-control" required>
                                    </div>

                                    <div class="col-md-6">
                                        <label>Affiliate Link *</label>
                                        <input type="text" name="affiliate_link" value="<?php echo e($product->affiliate_link); ?>"
                                            class="form-control" required>
                                        <small class="text-muted">
                                            Example:
                                            https://example.com/c?o=12345&m=888&a=999&aff_click_id={CLICK_ID}&sub_aff_id={USER_ID}
                                            <br>
                                            <b>{CLICK_ID}</b> auto-generate hoga when user clicks the link.
                                            <br>
                                            <b>{USER_ID}</b> user ka ID/subid store karne ke liye hota hai.
                                        </small>
                                    </div>

                                    <div class="col-md-6">
                                        <label>Subtitle</label>
                                        <input type="text" name="sub_title" value="<?php echo e($product->sub_title); ?>"
                                            class="form-control">
                                    </div>

                                    <div class="col-md-6">
                                        <label>Earnings (₹)</label>
                                        <input type="number" name="earnings" value="<?php echo e($product->earnings); ?>"
                                            class="form-control">
                                    </div>

                                    <div class="col-md-6">
                                        <label>Category *</label>
                                        <select name="category_id" class="form-control" required>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($c->id); ?>"
                                                    <?php echo e($product->category_id == $c->id ? 'selected' : ''); ?>>
                                                    <?php echo e($c->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label>Subcategory</label>
                                        <select name="subcategory_id" id="subcategory" class="form-control">
                                            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($sc->id); ?>"
                                                    <?php echo e($product->subcategory_id == $sc->id ? 'selected' : ''); ?>>
                                                    <?php echo e($sc->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-6">
                                        <label>Expiry Days</label>
                                        <input type="number" name="expiry_days" class="form-control"
                                            value="<?php echo e($product->expiry_days ?? 30); ?>" required>
                                    </div>



                                    <div class="col-md-12">
                                        <label>Description</label>
                                        <textarea name="description" class="form-control"><?php echo e($product->description); ?></textarea>
                                    </div>

                                    <div class="col-md-6">
                                        <label>Product Image</label>
                                        <input type="file" name="product_image" class="form-control">

                                        <?php if($product->product_image): ?>
                                            <img src="<?php echo e(asset('uploads/affiliate-products/' . $product->product_image)); ?>"
                                                width="80" class="mt-2">
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-md-6">
                                        <label>Banner</label>
                                        <input type="file" name="banner" class="form-control">

                                        <?php if($product->banner): ?>
                                            <img src="<?php echo e(asset('uploads/affiliate-products/' . $product->banner)); ?>"
                                                width="80" class="mt-2">
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-md-6">
                                        <label>Status</label>
                                        <select name="status" class="form-control">
                                            <option value="active" <?php echo e($product->status == 'active' ? 'selected' : ''); ?>>
                                                Active</option>
                                            <option value="inactive"
                                                <?php echo e($product->status == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                        </select>
                                    </div>

                                    <div class="col-md-6">
                                        <br>
                                        <label>
                                            <input type="checkbox" name="is_top_product"
                                                <?php echo e($product->is_top_product ? 'checked' : ''); ?>>
                                            Top Product?
                                        </label>

                                        <input type="text" name="top_product_title"
                                            value="<?php echo e($product->top_product_title); ?>" class="form-control mt-1">
                                    </div>

                                    <div class="col-md-6">
                                        <br>
                                        <label>
                                            <input type="checkbox" name="is_recommended"
                                                <?php echo e($product->is_recommended ? 'checked' : ''); ?>>
                                            Recommended?
                                        </label>
                                    </div>

                                </div>

                                <button class="btn btn-primary mt-3">Update Product</button>

                            </form>

                        </div>

                    </div>

                </div>
            </div>
        </div>

    </div>

    <script>
        document.getElementById("title").addEventListener("keyup", function() {
            let slug = this.value.toLowerCase().replace(/[^\w ]+/g, '').replace(/ +/g, '-');
            document.getElementById("slug").value = slug;
        });
    </script>
    <script>
        document.querySelector("select[name='category_id']").addEventListener("change", function() {

            let categoryId = this.value;

            fetch(`/admins/get-subcategories/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    let subcat = document.getElementById("subcategory");
                    subcat.innerHTML = `<option value="">Select Subcategory</option>`;

                    data.forEach(item => {
                        subcat.innerHTML += `<option value="${item.id}">${item.name}</option>`;
                    });
                });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/affiliate_products/edit.blade.php ENDPATH**/ ?>