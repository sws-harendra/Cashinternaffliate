<!DOCTYPE html>
<html lang="en">

<head>
    <title>Verify OTP</title>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('backend/assets/images/favicon.ico')); ?>" type="image/x-icon">

    <!-- Google font-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500" rel="stylesheet">

    <!-- Required Framework -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/assets/css/bootstrap/css/bootstrap.min.css')); ?>">

    <!-- waves.css -->
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/pages/waves/css/waves.min.css')); ?>" type="text/css">

    <!-- Icons -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/assets/icon/themify-icons/themify-icons.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/assets/icon/icofont/css/icofont.css')); ?>">
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('backend/assets/icon/font-awesome/css/font-awesome.min.css')); ?>">

    <!-- Style -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/assets/css/style.css')); ?>">
</head>

<body themebg-pattern="theme1">

<section class="login-block">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">

                <!-- OTP Form -->
                <form class="md-float-material form-material"
                      method="POST"
                      action="<?php echo e(route('recruiters.otp.verify')); ?>">
                    <?php echo csrf_field(); ?>

                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success mt-3">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger mt-3">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger mt-3">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="text-center">
                        <img src="<?php echo e(asset('backend/assets/images/logo.png')); ?>" alt="logo">
                    </div>

                    <div class="auth-box card">
                        <div class="card-block">

                            <div class="row m-b-20">
                                <div class="col-md-12">
                                    <h3 class="text-center">Verify OTP</h3>
                                    <p class="text-center text-muted mb-0">
                                        Enter OTP sent to your Email & Mobile
                                    </p>
                                </div>
                            </div>

                            
                            <div class="form-group form-primary">
                                <input type="text"
                                       name="email_otp"
                                       class="form-control"
                                       maxlength="6"
                                       required>
                                <span class="form-bar"></span>
                                <label class="float-label">Email OTP</label>
                            </div>

                            
                            <div class="form-group form-primary">
                                <input type="text"
                                       name="mobile_otp"
                                       class="form-control"
                                       maxlength="6"
                                       required>
                                <span class="form-bar"></span>
                                <label class="float-label">Mobile OTP</label>
                            </div>

                            <div class="row m-t-30">
                                <div class="col-md-12">
                                    <button type="submit"
                                            class="btn btn-primary btn-md btn-block waves-effect waves-light">
                                        Verify OTP
                                    </button>
                                </div>
                            </div>

                            <hr>

                            <div class="row">
                                <div class="col-md-12 text-center">
                                    <p class="text-inverse mb-0">
                                        Didn’t receive OTP?
                                    </p>
                                    <a href="<?php echo e(route('recruiters.otp.resend')); ?>">
                                        <b>Resend OTP</b>
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                </form>
                <!-- End form -->

            </div>
        </div>
    </div>
</section>

<!-- Scripts -->
<script src="<?php echo e(asset('backend/assets/js/jquery/jquery.min.js')); ?>"></cript>
<script src="<?php echo e(asset('backend/assets/js/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/popper.js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/pages/waves/js/waves.min.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/recruiters/auth/verify-otp.blade.php ENDPATH**/ ?>