

<?php $__env->startPush('title'); ?>
<title>Home Banners | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

    <!-- Page Header -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Home Banners</h5>
                        <p class="m-b-0">Manage homepage banners</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.dashboard')); ?>"><i class="fa fa-home"></i></a>
                        </li>
                        <li class="breadcrumb-item">Home Banners</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header">
                        <h5>Banner List</h5>
                        <a href="<?php echo e(route('admins.home-banner.create')); ?>"
                           class="btn btn-primary btn-sm float-right">Add Banner</a>
                    </div>

                    <div class="card-block">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Banner</th>
                                        <th>Title</th>
                                        <th>Product</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i + 1); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('uploads/home-banners/'.$b->banner)); ?>" width="80">
                                        </td>
                                        <td><?php echo e($b->title); ?></td>
                                        <td><?php echo e($b->product->title ?? 'N/A'); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admins.home-banner.edit', $b->id)); ?>"
                                               class="btn btn-warning btn-sm">Edit</a>
                                            <a href="<?php echo e(route('admins.home-banner.delete', $b->id)); ?>"
                                               onclick="return confirm('Delete banner?')"
                                               class="btn btn-danger btn-sm">Delete</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>

                        <?php echo e($banners->links()); ?>

                    </div>
                </div>

            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/home_banner/index.blade.php ENDPATH**/ ?>