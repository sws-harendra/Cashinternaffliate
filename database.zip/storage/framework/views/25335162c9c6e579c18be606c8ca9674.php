

<?php $__env->startPush('title'); ?>
    <title>Edit Earning Level | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="pcoded-content">

        <!-- Page-header start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Edit Earning Level</h5>
                            <p class="m-b-0">Modify earning level details</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('admins.dashboard')); ?>"> <i class="fa fa-home"></i> </a>
                            </li>
                            <li class="breadcrumb-item"><a
                                    href="<?php echo e(route('admins.earning-levels.index', $level->affiliate_product_id)); ?>">Earning
                                    Levels</a></li>
                            <li class="breadcrumb-item"><a href="#!">Edit</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page-header end -->

        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="card">
                        <div class="card-header">
                            <h5>Update Level</h5>
                        </div>

                        <div class="card-block">

                            <form method="POST" action="<?php echo e(route('admins.earning-levels.update', $level->id)); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label>Level Name</label>
                                    <input type="text" name="level_name" value="<?php echo e($level->level_name); ?>"
                                        class="form-control" required>
                                </div>

                                <div class="form-group">
                                    <label>Level Description</label>
                                    <input type="text" name="level_description" value="<?php echo e($level->level_description); ?>"
                                        class="form-control" required>
                                </div>

                                <div class="form-group">
                                    <label>Level Order *</label>
                                    <input type="number" name="level_order" class="form-control"
                                        value="<?php echo e($level->level_order); ?>" min="1" required>
                                    <small class="text-muted">Example: 1 = first step, 2 = second step...</small>
                                </div>

                                <div class="form-group">
                                    <label>Amount (₹)</label>
                                    <input type="number" step="0.01" name="amount" value="<?php echo e($level->amount); ?>"
                                        class="form-control" required>
                                </div>

                                <button class="btn btn-primary">Update</button>

                                <a href="<?php echo e(route('admins.earning-levels.index', $level->affiliate_product_id)); ?>"
                                    class="btn btn-secondary">Back</a>

                            </form>

                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/earning_levels/edit.blade.php ENDPATH**/ ?>