

<?php $__env->startPush('title'); ?>
    <title>Recruiter Dashboard | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="pcoded-content">
        <!-- Page-header start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Dashboard</h5>
                            <p class="m-b-0">Welcome to <?php echo e(env('APP_NAME')); ?> Recruiter Dashboard</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item">
                                <a href="index.html"> <i class="fa fa-home"></i> </a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Dashboard</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        

        <?php
            $verification = auth('recruiter')->user()->verification;
        ?>

        <?php if(!$verification): ?>
            
            <div class="card border-left-warning">
                <div class="card-block">
                    <h5 class="text-warning">
                        <i class="fa fa-warning"></i> Verification Required
                    </h5>
                    <p>
                        Please upload your verification document to enable job posting.
                    </p>
                    <a href="<?php echo e(route('recruiters.verification')); ?>" class="btn btn-warning btn-sm">
                        Upload Verification Document
                    </a>
                </div>
            </div>
        <?php else: ?>
            
            <div class="card">
                <div class="card-block">

                    <?php if($verification->status === 'pending'): ?>
                        <div class="alert alert-warning">
                            <strong>Verification Status:</strong> Pending Admin Review
                        </div>
                    <?php elseif($verification->status === 'approved'): ?>
                        <div class="alert alert-success">
                            <strong>Verification Status:</strong> Approved
                        </div>
                    <?php elseif($verification->status === 'rejected'): ?>
                        <div class="alert alert-danger">
                            <strong>Verification Rejected</strong><br>
                            Reason: <?php echo e($verification->admin_remark ?? 'N/A'); ?>

                            <br><br>
                            <a href="<?php echo e(route('recruiters.verification')); ?>" class="btn btn-danger btn-sm">
                                Re-upload Document
                            </a>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        <?php endif; ?>


        <!-- Page-header end -->
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.recruiters.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/recruiters/pages/dashboard.blade.php ENDPATH**/ ?>