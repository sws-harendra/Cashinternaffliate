

<?php $__env->startPush('title'); ?>
<title>Pending Jobs | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

<div class="page-header">
    <div class="page-block">
        <h5 class="m-b-10">Pending Job Approvals</h5>
        <p class="m-b-0">Review recruiter job postings</p>
    </div>
</div>

<?php echo $__env->make('backend.admins.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="card">
<div class="card-block table-responsive">

<table class="table table-hover">
    <thead>
        <tr>
            <th>#</th>
            <th>Title</th>
            <th>Recruiter</th>
            <th>Category</th>
            <th>Location</th>
            <th>Posted On</th>
            <th>Action</th>
        </tr>
    </thead>

    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($job->id); ?></td>
            <td><?php echo e($job->title); ?></td>
            <td><?php echo e($job->recruiter->name ?? 'N/A'); ?></td>
            <td><?php echo e($job->category->name ?? 'N/A'); ?></td>
            <td>
                <?php echo e(optional($job->location)->city); ?>,
                <?php echo e(optional($job->location)->state); ?>

            </td>
            <td><?php echo e($job->created_at->format('d M Y')); ?></td>
            <td>
                <a href="<?php echo e(route('admins.jobs.show', $job->id)); ?>"
                   class="btn btn-sm btn-primary">
                    Review
                </a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="7" class="text-center text-muted">
                No pending jobs found.
            </td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>

<?php echo e($jobs->links()); ?>


</div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/jobs/index.blade.php ENDPATH**/ ?>