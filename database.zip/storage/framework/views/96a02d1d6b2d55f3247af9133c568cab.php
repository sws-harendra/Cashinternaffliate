

<?php $__env->startPush('title'); ?>
<title>Review Job | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

<?php echo $__env->make('backend.admins.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="card">
<div class="card-header">
    <h5><?php echo e($job->title); ?></h5>
    <span class="text-muted">
        Recruiter: <?php echo e($job->recruiter->name); ?> (<?php echo e($job->recruiter->email); ?>)
    </span>
</div>

<div class="card-block">

<p><strong>Category:</strong> <?php echo e($job->category->name ?? 'N/A'); ?></p>
<p><strong>Role:</strong> <?php echo e($job->role->name ?? 'N/A'); ?></p>
<p><strong>Type:</strong> <?php echo e($job->type->name ?? 'N/A'); ?></p>
<p><strong>Location:</strong>
    <?php echo e(optional($job->location)->city); ?>,
    <?php echo e(optional($job->location)->state); ?>

</p>
<p><strong>Experience:</strong> <?php echo e($job->experience->label ?? 'N/A'); ?></p>
<p><strong>Salary:</strong> <?php echo e($job->salary->label ?? 'Not Disclosed'); ?></p>

<hr>

<h6>Description</h6>
<p><?php echo e($job->description); ?></p>

<?php if($job->responsibilities): ?>
<hr>
<h6>Responsibilities</h6>
<p><?php echo e($job->responsibilities); ?></p>
<?php endif; ?>

<?php if($job->skills): ?>
<hr>
<h6>Skills</h6>
<p><?php echo e($job->skills); ?></p>
<?php endif; ?>

<hr>

<div class="row">
    <div class="col-md-6">
        <form method="POST"
              action="<?php echo e(route('admins.jobs.approve', $job->id)); ?>">
            <?php echo csrf_field(); ?>
            <button class="btn btn-success btn-block">
                Approve Job
            </button>
        </form>
    </div>

    <div class="col-md-6">
        <form method="POST"
              action="<?php echo e(route('admins.jobs.reject', $job->id)); ?>">
            <?php echo csrf_field(); ?>
            <textarea name="reason"
                      class="form-control mb-2"
                      placeholder="Rejection reason"
                      required></textarea>
            <button class="btn btn-danger btn-block">
                Reject Job
            </button>
        </form>
    </div>
</div>

</div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/jobs/show.blade.php ENDPATH**/ ?>