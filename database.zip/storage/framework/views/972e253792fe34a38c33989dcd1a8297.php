

<?php $__env->startPush('title'); ?>
    <title>Edit Training Sub Category | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="pcoded-content">

        <!-- Page-header -->
        <div class="page-header">
            <div class="page-block">

                <div class="row align-items-center">

                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5>Edit Sub Category</h5>
                            <p class="m-b-0">Update training subcategory</p>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>"><i
                                        class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item"><a
                                    href="<?php echo e(route('admins.training-subcategory.index')); ?>">Subcategories</a></li>
                            <li class="breadcrumb-item"><a href="#!">Edit</a></li>
                        </ul>
                    </div>

                </div>

            </div>
        </div>

        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <?php if(session()->has('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header">
                            <h5>Update Sub Category</h5>
                        </div>

                        <div class="card-block">

                            <form action="<?php echo e(route('admins.training-subcategory.update', $subcategory->id)); ?>"
                                method="POST" enctype="multipart/form-data">

                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label>Select Category *</label>
                                    <select name="category_id" class="form-control" required>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($c->id); ?>"
                                                <?php echo e($subcategory->category_id == $c->id ? 'selected' : ''); ?>>
                                                <?php echo e($c->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Name *</label>
                                    <input type="text" name="name" class="form-control"
                                        value="<?php echo e($subcategory->name); ?>" required>
                                </div>

                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea name="description" class="form-control"><?php echo e($subcategory->description); ?></textarea>
                                </div>

                                <div class="form-group">
                                    <label>Banner</label>
                                    <input type="file" name="banner" class="form-control">

                                    <?php if($subcategory->banner): ?>
                                        <img src="<?php echo e(asset('uploads/training-subcategory/' . $subcategory->banner)); ?>"
                                            width="80" class="mt-2">
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label>Status</label>
                                    <select name="status" class="form-control">
                                        <option value="1" <?php echo e($subcategory->status ? 'selected' : ''); ?>>Active</option>
                                        <option value="0" <?php echo e(!$subcategory->status ? 'selected' : ''); ?>>Inactive
                                        </option>
                                    </select>
                                </div>

                                <button class="btn btn-primary">Update</button>

                                <a href="<?php echo e(route('admins.training-subcategory.index')); ?>"
                                    class="btn btn-secondary">Back</a>

                            </form>

                        </div>

                    </div>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/training_subcategory/edit.blade.php ENDPATH**/ ?>