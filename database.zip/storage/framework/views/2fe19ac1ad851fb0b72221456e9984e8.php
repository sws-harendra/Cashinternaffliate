

<?php $__env->startPush('title'); ?>
    <title>Add Job Type | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Add Job Type</h5>
                        <p class="m-b-0">Create a new job type</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.dashboard')); ?>">
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.job-types.index')); ?>">Job Types</a>
                        </li>
                        <li class="breadcrumb-item">Add</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('backend.admins.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="card">
        <div class="card-block">

            <form method="POST" action="<?php echo e(route('admins.job-types.store')); ?>">
                <?php echo csrf_field(); ?>

                <?php echo $__env->make('backend.admins.pages.job_types._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <div class="mt-3">
                    <button type="submit" class="btn btn-success">
                        Save Job Type
                    </button>

                    <a href="<?php echo e(route('admins.job-types.index')); ?>"
                       class="btn btn-secondary">
                        Cancel
                    </a>
                </div>

            </form>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/job_types/create.blade.php ENDPATH**/ ?>