<div class="form-group">
    <label>Experience Level <span class="text-danger">*</span></label>
    <input type="text"
           name="label"
           class="form-control"
           placeholder="e.g. Fresher, 1–3 Years, 5+ Years"
           value="<?php echo e(old('label', $experienceLevel->label ?? '')); ?>"
           required>
</div>

<div class="form-group">
    <label>Status</label>
    <select name="is_active" class="form-control">
        <option value="1"
            <?php echo e(old('is_active', $experienceLevel->is_active ?? 1) == 1 ? 'selected' : ''); ?>>
            Active
        </option>
        <option value="0"
            <?php echo e(old('is_active', $experienceLevel->is_active ?? 1) == 0 ? 'selected' : ''); ?>>
            Inactive
        </option>
    </select>
</div>
<?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/experience_levels/_form.blade.php ENDPATH**/ ?>