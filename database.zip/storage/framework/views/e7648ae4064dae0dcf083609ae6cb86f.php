

<?php $__env->startPush('title'); ?>
    <title>Settings | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="pcoded-content">

        <!-- Page-header start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">App Settings</h5>
                            <p class="m-b-0">Manage all configuration settings</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('admins.dashboard')); ?>"> <i class="fa fa-home"></i> </a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Settings</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page-header end -->

        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <div class="page-body">
                        <div class="card">
                            <div class="card-header">
                                <h5>Manage Settings</h5>
                            </div>

                            <div class="card-block">

                                <?php if(session('success')): ?>
                                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                <?php endif; ?>

                                <form method="POST" action="<?php echo e(route('admins.settings.update')); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="row">

                                        <div class="col-md-6">
                                            <label>Playstore App Link</label>
                                            <input type="text" class="form-control" name="playstore_app_link"
                                                value="<?php echo e($settings['playstore_app_link'] ?? ''); ?>">
                                        </div>

                                        <div class="col-md-6">
                                            <label>Website Link</label>
                                            <input type="text" class="form-control" name="website_link"
                                                value="<?php echo e($settings['website_link'] ?? ''); ?>">
                                        </div>

                                        <div class="col-md-6">
                                            <label>Terms & Condition Link</label>
                                            <input type="text" class="form-control" name="terms_link"
                                                value="<?php echo e($settings['terms_link'] ?? ''); ?>">
                                        </div>

                                        <div class="col-md-6">
                                            <label>Privacy Policy Link</label>
                                            <input type="text" class="form-control" name="privacy_link"
                                                value="<?php echo e($settings['privacy_link'] ?? ''); ?>">
                                        </div>

                                        <div class="col-md-6">
                                            <label>Telegram Link</label>
                                            <input type="text" class="form-control" name="telegram_link"
                                                value="<?php echo e($settings['telegram_link'] ?? ''); ?>">
                                        </div>

                                        <div class="col-md-6">
                                            <label>Facebook Link</label>
                                            <input type="text" class="form-control" name="facebook_link"
                                                value="<?php echo e($settings['facebook_link'] ?? ''); ?>">
                                        </div>

                                        <div class="col-md-6">
                                            <label>Instagram Link</label>
                                            <input type="text" class="form-control" name="instagram_link"
                                                value="<?php echo e($settings['instagram_link'] ?? ''); ?>">
                                        </div>

                                        <div class="col-md-6">
                                            <label>YouTube Link</label>
                                            <input type="text" class="form-control" name="youtube_link"
                                                value="<?php echo e($settings['youtube_link'] ?? ''); ?>">
                                        </div>

                                        <div class="col-md-6">
                                            <label>Support Email</label>
                                            <input type="email" class="form-control" name="support_email"
                                                value="<?php echo e($settings['support_email'] ?? ''); ?>">
                                        </div>

                                        <div class="col-md-6">
                                            <label>Referral Bonus (%)</label>
                                            <input type="number" class="form-control" name="referral_bonus"
                                                value="<?php echo e($settings['referral_bonus'] ?? 0); ?>">
                                        </div>

                                        <div class="col-md-6">
                                            <label>Minimum Withdraw (₹)</label>
                                            <input type="number" class="form-control" name="min_withdraw"
                                                value="<?php echo e($settings['min_withdraw'] ?? 0); ?>">
                                        </div>

                                        <div class="col-md-6">
                                            <label>Company Logo</label><br>
                                            <input type="file" name="company_logo" class="form-control">

                                            <?php if(!empty($settings['company_logo'])): ?>
                                                <img src="<?php echo e(asset($settings['company_logo'])); ?>" class="img-60 mt-2"
                                                    alt="Company Logo">
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-6 mt-3">
                                            <label>Referral Banner</label><br>
                                            <input type="file" name="refer_banner" class="form-control">

                                            <?php if(!empty($settings['refer_banner'])): ?>
                                                <img src="<?php echo e(asset($settings['refer_banner'])); ?>" class="img-60 mt-2"
                                                    alt="Referral Banner">
                                            <?php endif; ?>
                                        </div>


                                    </div>

                                    <button class="btn btn-primary mt-4">Save Settings</button>

                                </form>

                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/settings.blade.php ENDPATH**/ ?>