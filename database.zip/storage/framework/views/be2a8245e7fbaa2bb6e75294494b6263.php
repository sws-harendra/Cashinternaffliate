

<?php $__env->startPush('title'); ?>
<title>My Jobs | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

    <!-- Page Header -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">My Job Posts</h5>
                        <p class="m-b-0">Manage your job postings</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('backend.recruiters.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="card">
        <div class="card-block table-responsive">

            <a href="<?php echo e(route('recruiters.jobs.create')); ?>"
               class="btn btn-primary mb-3">
                + Post New Job
            </a>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Posted On</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($job->id); ?></td>
                        <td><?php echo e($job->title); ?></td>
                        <td><?php echo e($job->category->name); ?></td>
                        <td><?php echo e($job->location->city); ?>, <?php echo e($job->location->state); ?></td>

                        <td>
                            <?php if($job->status === 'approved'): ?>
                                <span class="badge badge-success">Approved</span>
                            <?php elseif($job->status === 'pending'): ?>
                                <span class="badge badge-warning">Pending</span>
                            <?php elseif($job->status === 'rejected'): ?>
                                <span class="badge badge-danger">Rejected</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">Draft</span>
                            <?php endif; ?>
                        </td>

                        <td><?php echo e($job->created_at->format('d M Y')); ?></td>

                        <td>
                            <?php if($job->status !== 'approved'): ?>
                                <a href="<?php echo e(route('recruiters.jobs.edit', $job->id)); ?>"
                                   class="btn btn-sm btn-info">
                                    Edit
                                </a>
                            <?php else: ?>
                                <span class="text-muted">Locked</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">
                            No jobs posted yet.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>

            <?php echo e($jobs->links()); ?>


        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.recruiters.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/recruiters/pages/jobs/index.blade.php ENDPATH**/ ?>