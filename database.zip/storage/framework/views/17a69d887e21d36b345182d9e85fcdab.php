

<?php $__env->startPush('title'); ?>
    <title>Affiliate Products | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="pcoded-content">

        <!-- Page-header start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Affiliate Products</h5>
                            <p class="m-b-0">Manage all affiliate products</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('admins.dashboard')); ?>"> <i class="fa fa-home"></i> </a>
                            </li>
                            <li class="breadcrumb-item"><a href="#!">Affiliate Products</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page-header end -->

        <div class="pcoded-inner-content">
            <div class="main-body">
                <div class="page-wrapper">

                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header">
                            <h5>Products List</h5>
                            <a href="<?php echo e(route('admins.affiliate-products.create')); ?>"
                                class="btn btn-primary btn-sm float-right">Add New</a>
                        </div>

                        <div class="card-block">

                            <div class="table-responsive">
                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Image</th>
                                            <th>Title</th>
                                            <th>Category</th>
                                            <th>Earnings</th>
                                            <th>Status</th>
                                            <th>Top Product</th>
                                            <th>Recommended</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key + 1); ?></td>

                                                <td>
                                                    <?php if($p->product_image): ?>
                                                        <img src="<?php echo e(asset('uploads/affiliate-products/' . $p->product_image)); ?>"
                                                            width="50">
                                                    <?php else: ?>
                                                        No Image
                                                    <?php endif; ?>
                                                </td>

                                                <td><?php echo e($p->title); ?></td>

                                                <td><?php echo e($p->category->name ?? ''); ?></td>

                                                <td>₹<?php echo e($p->earnings); ?></td>

                                                <td>
                                                    <span
                                                        class="badge 
                                                <?php echo e($p->status == 'active' ? 'badge-success' : 'badge-danger'); ?>">
                                                        <?php echo e(ucfirst($p->status)); ?>

                                                    </span>
                                                </td>

                                                <td>
                                                    <?php if($p->is_top_product): ?>
                                                        <span class="badge badge-info">Yes</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-secondary">No</span>
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <?php if($p->is_recommended): ?>
                                                        <span class="badge badge-info">Yes</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-secondary">No</span>
                                                    <?php endif; ?>
                                                </td>

                                                <td >
                                                    <a href="<?php echo e(route('admins.affiliate-products.edit', $p->id)); ?>"
                                                        class="btn btn-warning btn-sm">Edit</a>

                                                    <a href="<?php echo e(route('admins.affiliate-products.details', $p->id)); ?>"
                                                        class="btn btn-info btn-sm">
                                                        Manage Details
                                                    </a>
                                                    <a href="<?php echo e(route('admins.earning-levels.index', $p->id)); ?>"
                                                        class="btn btn-primary btn-sm">
                                                        Earning Levels
                                                    </a>


                                                    <a onclick="return confirm('Delete this product?')"
                                                        href="<?php echo e(route('admins.affiliate-products.delete', $p->id)); ?>"
                                                        class="btn btn-danger btn-sm">Delete</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>

                            <?php echo e($products->links()); ?>


                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/affiliate_products/index.blade.php ENDPATH**/ ?>