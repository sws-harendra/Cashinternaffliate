

<?php $__env->startPush('title'); ?>
    <title>Recruiter Verifications | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Recruiter Verifications</h5>
                        <p class="m-b-0">Manage recruiter document verification</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.dashboard')); ?>">
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item">Recruiter Verifications</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <?php echo $__env->make('backend.admins.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="card">
        <div class="card-block table-responsive">

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Recruiter</th>
                        <th>Email</th>
                        <th>Document</th>
                        <th>Status</th>
                        <th>Submitted At</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $verifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($v->id); ?></td>
                        <td><?php echo e($v->recruiter->name); ?></td>
                        <td><?php echo e($v->recruiter->email); ?></td>
                        <td><?php echo e($v->document_type); ?></td>

                        <td>
                            <?php if($v->status === 'pending'): ?>
                                <span class="badge badge-warning">Pending</span>
                            <?php elseif($v->status === 'approved'): ?>
                                <span class="badge badge-success">Approved</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Rejected</span>
                            <?php endif; ?>
                        </td>

                        <td><?php echo e($v->created_at->format('d M Y')); ?></td>

                        <td>
                            <a href="<?php echo e(route('admins.recruiter.verifications.show', $v->id)); ?>"
                               class="btn btn-sm btn-primary">
                                View
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">
                            No recruiter verification records found.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>

            <?php echo e($verifications->links()); ?>


        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/recruiter_verifications/index.blade.php ENDPATH**/ ?>