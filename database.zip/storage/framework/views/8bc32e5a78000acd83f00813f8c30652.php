<div class="form-group">
    <label>Job Category <span class="text-danger">*</span></label>
    <select name="job_category_id" class="form-control" required>
        <option value="">-- Select Category --</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>"
                <?php echo e(old('job_category_id', $jobRole->job_category_id ?? '') == $category->id ? 'selected' : ''); ?>>
                <?php echo e($category->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label>Role Name <span class="text-danger">*</span></label>
    <input type="text"
           name="name"
           class="form-control"
           value="<?php echo e(old('name', $jobRole->name ?? '')); ?>"
           placeholder="e.g. PHP Developer, Sales Executive"
           required>
</div>

<div class="form-group">
    <label>Status</label>
    <select name="is_active" class="form-control">
        <option value="1"
            <?php echo e(old('is_active', $jobRole->is_active ?? 1) == 1 ? 'selected' : ''); ?>>
            Active
        </option>
        <option value="0"
            <?php echo e(old('is_active', $jobRole->is_active ?? 1) == 0 ? 'selected' : ''); ?>>
            Inactive
        </option>
    </select>
</div>
<?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/job_roles/_form.blade.php ENDPATH**/ ?>