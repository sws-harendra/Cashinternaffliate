<div class="form-group">
    <label>Job Type <span class="text-danger">*</span></label>
    <input type="text"
           name="name"
           class="form-control"
           placeholder="e.g. Full Time, Part Time, Internship"
           value="<?php echo e(old('name', $jobType->name ?? '')); ?>"
           required>
</div>

<div class="form-group">
    <label>Status</label>
    <select name="is_active" class="form-control">
        <option value="1"
            <?php echo e(old('is_active', $jobType->is_active ?? 1) == 1 ? 'selected' : ''); ?>>
            Active
        </option>
        <option value="0"
            <?php echo e(old('is_active', $jobType->is_active ?? 1) == 0 ? 'selected' : ''); ?>>
            Inactive
        </option>
    </select>
</div>
<?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/job_types/_form.blade.php ENDPATH**/ ?>