

<?php $__env->startPush('title'); ?>
<title>Edit Affiliate Subcategory | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Edit Affiliate Subcategory</h5>
                        <p class="m-b-0">Update subcategory details</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admins.affiliate-subcategories.index')); ?>">Subcategories</a></li>
                        <li class="breadcrumb-item">Edit</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">

                    <div class="card">
                        <div class="card-header"><h5>Update Subcategory</h5></div>

                        <div class="card-block">

                            <?php if(session('success')): ?>
                                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                            <?php endif; ?>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul class="m-0">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($err); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <form action="<?php echo e(route('admins.affiliate-subcategories.update', $subcategory->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="row">

                                    <div class="col-md-6">
                                        <label>Name *</label>
                                        <input type="text" name="name" class="form-control" value="<?php echo e($subcategory->name); ?>" required>
                                    </div>

                                    <div class="col-md-6">
                                        <label>Slug *</label>
                                        <input type="text" name="slug" class="form-control" value="<?php echo e($subcategory->slug); ?>" required>
                                    </div>

                                    <div class="col-md-6 mt-3">
                                        <label>Category *</label>
                                        <select name="category_id" class="form-control" required>
                                            <option value="">-- Select Category --</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($cat->id); ?>" <?php echo e($cat->id == $subcategory->category_id ? 'selected':''); ?>>
                                                    <?php echo e($cat->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-6 mt-3">
                                        <label>Status</label>
                                        <select name="status" class="form-control">
                                            <option value="active" <?php echo e($subcategory->status == 'active' ? 'selected': ''); ?>>Active</option>
                                            <option value="inactive" <?php echo e($subcategory->status == 'inactive' ? 'selected': ''); ?>>Inactive</option>
                                        </select>
                                    </div>

                                    <div class="col-md-12 mt-3">
                                        <label>Description</label>
                                        <textarea name="description" class="form-control" rows="3"><?php echo e($subcategory->description); ?></textarea>
                                    </div>

                                    <div class="col-md-6 mt-3">
                                        <label>Old Banner</label><br>
                                        <?php if($subcategory->banner): ?>
                                            <img src="<?php echo e(asset('uploads/affiliate-subcategories/'.$subcategory->banner)); ?>" height="80" class="img-radius mb-2">
                                        <?php else: ?>
                                            <p class="text-muted">No Image</p>
                                        <?php endif; ?>
                                        <input type="file" name="banner" class="form-control mt-2">
                                    </div>

                                </div>

                                <button class="btn btn-primary mt-4">Update Subcategory</button>
                            </form>

                        </div>
                    </div>

                </div> 
            </div>
        </div>
    </div>
</div>

<script>
    function slugify(text) {
        return text.toString().toLowerCase().trim()
            .replace(/\s+/g, '-')
            .replace(/[^\w\-]+/g, '')
            .replace(/\-\-+/g, '-');
    }

    document.addEventListener('DOMContentLoaded', function(){
        const nameInput = document.querySelector("input[name='name']");
        const slugInput = document.querySelector("input[name='slug']");
        if(nameInput && slugInput){
            nameInput.addEventListener('keyup', function(){
                slugInput.value = slugify(this.value);
            });
        }
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/affiliate_sub_categories/edit.blade.php ENDPATH**/ ?>