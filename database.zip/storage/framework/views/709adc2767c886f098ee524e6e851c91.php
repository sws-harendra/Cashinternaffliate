

<?php $__env->startPush('title'); ?>
<title>Affiliate Subcategories | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">
    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Affiliate Subcategories</h5>
                        <p class="m-b-0">Manage sub-categories for affiliate categories</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admins.dashboard')); ?>"><i class="fa fa-home"></i></a></li>
                        <li class="breadcrumb-item">Affiliate</li>
                        <li class="breadcrumb-item">Subcategories</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">

                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header">
                            <h5>Subcategory List</h5>
                            <div class="card-header-right">
                                <a href="<?php echo e(route('admins.affiliate-subcategories.create')); ?>" class="btn btn-primary btn-sm">+ Add Subcategory</a>
                            </div>
                        </div>

                        <div class="card-block">
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Slug</th>
                                            <th>Category</th>
                                            <th>Banner</th>
                                            <th>Status</th>
                                            <th width="160px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($sub->id); ?></td>
                                                <td><?php echo e($sub->name); ?></td>
                                                <td><?php echo e($sub->slug); ?></td>
                                                <td><?php echo e(optional($sub->category)->name); ?></td>
                                                <td>
                                                    <?php if($sub->banner): ?>
                                                        <img src="<?php echo e(asset('uploads/affiliate-subcategories/'.$sub->banner)); ?>" height="40" class="img-radius">
                                                    <?php else: ?>
                                                        <span class="text-muted">No Image</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($sub->status === 'active'): ?>
                                                        <span class="label label-success">Active</span>
                                                    <?php else: ?>
                                                        <span class="label label-danger">Inactive</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('admins.affiliate-subcategories.edit', $sub->id)); ?>" class="btn btn-warning btn-sm">Edit</a>

                                                    <a href="<?php echo e(route('admins.affiliate-subcategories.delete', $sub->id)); ?>"
                                                       onclick="return confirm('Delete this subcategory?')"
                                                       class="btn btn-danger btn-sm">Delete</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="7" class="text-center text-muted">No subcategories found.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="mt-3">
                                <?php echo e($subcategories->links()); ?>

                            </div>

                        </div>
                    </div>

                </div> 
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/affiliate_sub_categories/index.blade.php ENDPATH**/ ?>