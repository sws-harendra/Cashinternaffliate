

<?php $__env->startPush('title'); ?>
<title>Edit Training Video | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>

<div class="pcoded-content">

    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">

                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Edit Training Video</h5>
                        <p class="m-b-0">Update training video details</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.dashboard')); ?>"> <i class="fa fa-home"></i> </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.training-videos.index')); ?>">Training Videos</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">Edit</a></li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <div class="card">
                    <div class="card-header">
                        <h5>Edit Video</h5>
                    </div>

                    <div class="card-block">

                        <form method="POST" action="<?php echo e(route('admins.training-videos.update', $video->id)); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label>Sub Category *</label>
                                <select name="sub_category_id" class="form-control" required>
                                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($c->id); ?>"
                                            <?php echo e($video->sub_category_id == $c->id ? 'selected' : ''); ?>>
                                            <?php echo e($c->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Video Title *</label>
                                <input type="text" name="title" class="form-control" value="<?php echo e($video->title); ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" class="form-control"><?php echo e($video->description); ?></textarea>
                            </div>

                            <div class="form-group">
                                <label>Video URL *</label>
                                <input type="text" name="video_url" value="<?php echo e($video->video_url); ?>" class="form-control" required>
                            </div>

                            <div class="form-group">
                                <label>Duration (seconds)</label>
                                <input type="number" name="duration" value="<?php echo e($video->duration); ?>" class="form-control">
                            </div>

                            <div class="form-group">
                                <label>Status *</label>
                                <select name="status" class="form-control">
                                    <option value="1" <?php echo e($video->status ? 'selected' : ''); ?>>Active</option>
                                    <option value="0" <?php echo e(!$video->status ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                            </div>

                            <button class="btn btn-primary">Update Video</button>

                        </form>

                    </div>

                </div>

            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/training_videos/edit.blade.php ENDPATH**/ ?>