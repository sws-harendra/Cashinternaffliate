

<?php $__env->startPush('title'); ?>
    <title>Edit Job Category | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="pcoded-content">

        <!-- Page-header -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Edit Job Category</h5>
                            <p class="m-b-0">Update job category details</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <ul class="breadcrumb-title">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('admins.dashboard')); ?>">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('admins.job-categories.index')); ?>">
                                    Job Categories
                                </a>
                            </li>
                            <li class="breadcrumb-item">Edit</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('backend.admins.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="card">
            <div class="card-block">

                <form method="POST" action="<?php echo e(route('admins.job-categories.update', $jobCategory->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group">
                        <label>Category Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control"
                            value="<?php echo e(old('name', $jobCategory->name ?? '')); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Status</label>
                        <select name="is_active" class="form-control">
                            <option value="1"
                                <?php echo e(old('is_active', $jobCategory->is_active ?? 1) == 1 ? 'selected' : ''); ?>>
                                Active
                            </option>
                            <option value="0"
                                <?php echo e(old('is_active', $jobCategory->is_active ?? 1) == 0 ? 'selected' : ''); ?>>
                                Inactive
                            </option>
                        </select>
                    </div>


                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary">
                            Update Category
                        </button>

                        <a href="<?php echo e(route('admins.job-categories.index')); ?>" class="btn btn-secondary">
                            Cancel
                        </a>
                    </div>

                </form>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/job_categories/edit.blade.php ENDPATH**/ ?>