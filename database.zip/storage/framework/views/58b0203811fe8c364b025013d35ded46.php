

<?php $__env->startPush('title'); ?>
<title>Affiliate Clicks | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>

<div class="pcoded-content">

    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Affiliate Clicks</h5>
                        <p class="m-b-0">View & manage all leads</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.dashboard')); ?>"> <i class="fa fa-home"></i> </a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">Affiliate Clicks</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <div class="card">
                    <div class="card-header">
                        <h5>Click Logs</h5>
                    </div>

                    <div class="card-block">

                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Lead ID</th>
                                        <th>Product</th>
                                        <th>User</th>
                                        <th>Click ID</th>
                                        <th>Completion</th>
                                        <th>Status</th>
                                        <th>Expiry</th>
                                        <th>Clicked At</th>
                                        <th>Convert</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $clicks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $click): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $isExpired = $click->isExpired();
                                            $expiryDate = $click->expiryDate();
                                        ?>

                                        <tr>
                                            <td><?php echo e($i + 1); ?></td>

                                            <td><?php echo e($click->lead_id); ?></td>

                                            <td><?php echo e($click->product->title ?? 'N/A'); ?></td>

                                            <td><?php echo e($click->user->name ?? 'Guest'); ?></td>

                                            <td><?php echo e($click->click_id); ?></td>

                                            <td>
                                                <?php if($isExpired): ?>
                                                    <span class="badge badge-danger">Expired</span>
                                                <?php elseif($click->is_converted): ?>
                                                    <span class="badge badge-success">Completed</span>
                                                <?php else: ?>
                                                    <span class="badge badge-warning">Pending</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($click->status == 0): ?>
                                                    <span class="badge badge-warning">Pending</span>
                                                <?php elseif($click->status == 1): ?>
                                                    <span class="badge badge-success">Progress</span>
                                                <?php elseif($click->status == 2): ?>
                                                    <span class="badge badge-danger">Rejected</span>
                                                <?php elseif($click->status == 3): ?>
                                                    <span class="badge badge-info">Completed</span>
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <?php if($expiryDate): ?>
                                                    <?php echo e($expiryDate->format('d M Y h:i A')); ?>

                                                <?php else: ?>
                                                    —
                                                <?php endif; ?>
                                            </td>

                                            <td><?php echo e($click->clicked_at); ?></td>

                                            <td>
                                                <?php if($isExpired): ?>
                                                    <button class="btn btn-secondary btn-sm" disabled>Expired</button>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('admins.affiliate.clicks.convert', $click->id)); ?>"
                                                       class="btn btn-primary btn-sm">
                                                        Convert
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>

                        <?php echo e($clicks->links()); ?>


                    </div>
                </div>

            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/clicks/index.blade.php ENDPATH**/ ?>