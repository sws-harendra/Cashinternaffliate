

<?php $__env->startPush('title'); ?>
<title>Affiliate Categories | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Affiliate Categories</h5>
                        <p class="m-b-0">Manage all affiliate categories created by admin</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.dashboard')); ?>"> <i class="fa fa-home"></i> </a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">Affiliate</a></li>
                        <li class="breadcrumb-item"><a href="#!">Categories</a></li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <div class="page-body">

                    <!-- Success message -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header">
                            <h5>Category List</h5>
                            <div class="card-header-right">
                                <a href="<?php echo e(route('admins.affiliate-categories.create')); ?>" 
                                   class="btn btn-primary btn-sm">
                                    + Add Category
                                </a>
                            </div>
                        </div>

                        <div class="card-block">

                            <div class="table-responsive">
                                <table class="table table-hover table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Slug</th>
                                            <th>Banner</th>
                                            <th>Status</th>
                                            <th width="150px">Action</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($category->id); ?></td>
                                            <td><?php echo e($category->name); ?></td>
                                            <td><?php echo e($category->slug); ?></td>

                                            <td>
                                                <?php if($category->banner): ?>
                                                    <img src="<?php echo e(asset('uploads/affiliate-categories/'.$category->banner)); ?>" 
                                                         height="40" class="img-radius">
                                                <?php else: ?>
                                                    <span class="text-muted">No Image</span>
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <?php if($category->status === 'active'): ?>
                                                    <span class="label label-success">Active</span>
                                                <?php else: ?>
                                                    <span class="label label-danger">Inactive</span>
                                                <?php endif; ?>
                                            </td>

                                            <td>

                                                <a href="<?php echo e(route('admins.affiliate-categories.edit', $category->id)); ?>" 
                                                   class="btn btn-info btn-sm">
                                                    Edit
                                                </a>

                                                <a href="<?php echo e(route('admins.affiliate-categories.delete', $category->id)); ?>"
                                                   onclick="return confirm('Are you sure you want to delete this category?')"
                                                   class="btn btn-danger btn-sm">
                                                   Delete
                                                </a>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="6" class="text-center text-muted">
                                                    No Categories Found
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>

                                </table>
                            </div>

                            <!-- Pagination links -->
                            <div>
                                <?php echo e($categories->links()); ?>

                            </div>

                        </div>
                    </div>

                </div> <!-- page-body end -->

            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/affiliate_categories/index.blade.php ENDPATH**/ ?>