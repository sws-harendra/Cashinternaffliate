

<?php $__env->startPush('title'); ?>
    <title>Recruiter Details | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

    <!-- Page Header -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Recruiter Details</h5>
                        <p class="m-b-0">Complete recruiter information</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.dashboard')); ?>">
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.recruiters.index')); ?>">
                                Recruiters
                            </a>
                        </li>
                        <li class="breadcrumb-item">Details</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('backend.admins.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <div class="card">
        <div class="card-header"><h5>Basic Information</h5></div>
        <div class="card-block">
            <p><strong>Name:</strong> <?php echo e($recruiter->name); ?></p>
            <p><strong>Email:</strong> <?php echo e($recruiter->email); ?></p>
            <p><strong>Mobile:</strong> <?php echo e($recruiter->mobile); ?></p>
            <p><strong>Status:</strong>
                <?php if($recruiter->is_active): ?>
                    <span class="badge badge-success">Active</span>
                <?php else: ?>
                    <span class="badge badge-danger">Inactive</span>
                <?php endif; ?>
            </p>
        </div>
    </div>

    
    <?php if($recruiter->profile): ?>
    <div class="card mt-3">
        <div class="card-header"><h5>Company Profile</h5></div>
        <div class="card-block">
            <?php if($recruiter->profile->logo): ?>
                <img src="<?php echo e(asset($recruiter->profile->logo)); ?>"
                     style="height:70px"><hr>
            <?php endif; ?>
            <p><strong>Industry:</strong> <?php echo e($recruiter->profile->industry); ?></p>
            <p><strong>Company Size:</strong> <?php echo e($recruiter->profile->company_size); ?></p>
            <p><strong>Address:</strong> <?php echo e($recruiter->profile->address); ?></p>
            <p><strong>Website:</strong> <?php echo e($recruiter->profile->website); ?></p>
            <p><strong>HR:</strong>
                <?php echo e($recruiter->profile->hr_name); ?> (<?php echo e($recruiter->profile->hr_contact); ?>)
            </p>
        </div>
    </div>
    <?php endif; ?>

    
    <div class="card mt-3">
        <div class="card-header"><h5>Verification Status</h5></div>
        <div class="card-block">
            <?php if(!$recruiter->verification): ?>
                <span class="badge badge-secondary">Not Uploaded</span>
            <?php else: ?>
                <span class="badge badge-info">
                    <?php echo e(ucfirst($recruiter->verification->status)); ?>

                </span>
                <br><br>
                <a href="<?php echo e(asset($recruiter->verification->document_file)); ?>"
                   target="_blank"
                   class="btn btn-info btn-sm">
                    View Document
                </a>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/recruiters/show.blade.php ENDPATH**/ ?>