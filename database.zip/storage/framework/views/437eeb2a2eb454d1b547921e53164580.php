

<?php $__env->startPush('title'); ?>
<title>Payment Verification | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Payment Verification</h5>
                        <p class="m-b-0">Verify user UPI & Bank details</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.dashboard')); ?>">
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">Payment Methods</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header">
                        <h5>User Payment Methods</h5>
                    </div>

                    <div class="card-block table-responsive">

                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>User Details</th>
                                    <th>Payment Type</th>
                                    <th>Payment Info</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>

                                        <!-- USER DETAILS -->
                                        <td>
                                            <strong><?php echo e($method->user->name ?? 'N/A'); ?></strong><br>
                                            <small>Email: <?php echo e($method->user->email ?? '-'); ?></small><br>
                                            <small>Phone: <?php echo e($method->user->phone ?? '-'); ?></small><br>
                                            <small>User UUID: <?php echo e($method->user_id); ?></small>
                                        </td>

                                        <!-- TYPE -->
                                        <td>
                                            <span class="badge badge-info">
                                                <?php echo e(strtoupper($method->type)); ?>

                                            </span>
                                        </td>

                                        <!-- PAYMENT DETAILS -->
                                        <td>
                                            <?php if($method->type === 'upi'): ?>
                                                <b>UPI ID:</b> <?php echo e($method->upi_id); ?><br>
                                                <b>Name:</b> <?php echo e($method->holder_name); ?>

                                            <?php else: ?>
                                                <b>Bank:</b> <?php echo e($method->bank_name); ?><br>
                                                <b>Account:</b> XXXX<?php echo e(substr($method->account_number, -4)); ?><br>
                                                <b>IFSC:</b> <?php echo e($method->ifsc_code); ?><br>
                                                <b>Name:</b> <?php echo e($method->holder_name); ?>

                                            <?php endif; ?>
                                        </td>

                                        <!-- STATUS -->
                                        <td>
                                            <?php if($method->verification_status === 'pending'): ?>
                                                <span class="badge badge-warning">Pending</span>
                                            <?php elseif($method->verification_status === 'approved'): ?>
                                                <span class="badge badge-success">Approved</span><br>
                                                <small>
                                                    <?php echo e(optional($method->verified_at)->format('d M Y h:i A')); ?>

                                                </small>
                                            <?php else: ?>
                                                <span class="badge badge-danger">Rejected</span><br>
                                                <small><?php echo e($method->rejection_reason); ?></small>
                                            <?php endif; ?>
                                        </td>

                                        <!-- ACTION -->
                                        <td>
                                            <?php if($method->verification_status === 'pending'): ?>

                                                <form method="POST"
                                                      action="<?php echo e(route('admins.payment.methods.approve', $method->id)); ?>"
                                                      style="display:inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-success btn-sm">
                                                        Approve
                                                    </button>
                                                </form>

                                                <button class="btn btn-danger btn-sm"
                                                        data-toggle="modal"
                                                        data-target="#rejectModal<?php echo e($method->id); ?>">
                                                    Reject
                                                </button>

                                            <?php else: ?>
                                                —
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <!-- Reject Modal -->
                                    <div class="modal fade" id="rejectModal<?php echo e($method->id); ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <form method="POST"
                                                  action="<?php echo e(route('admins.payment.methods.reject', $method->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Reject Payment Method</h5>
                                                        <button type="button" class="close" data-dismiss="modal">
                                                            &times;
                                                        </button>
                                                    </div>

                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label>Rejection Reason</label>
                                                            <textarea name="rejection_reason"
                                                                      class="form-control"
                                                                      required></textarea>
                                                        </div>
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button class="btn btn-danger">
                                                            Reject
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">
                                            No payment methods found
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <?php echo e($methods->links()); ?>


                    </div>
                </div>

            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/payment_methods/index.blade.php ENDPATH**/ ?>