

<?php $__env->startPush('title'); ?>
<title>Lead Conversion | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

    <!-- Page-header start -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Lead Conversion Panel</h5>
                        <p class="m-b-0">Manage and approve earning levels</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.dashboard')); ?>"><i class="fa fa-home"></i></a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.affiliate.clicks')); ?>">Affiliate Clicks</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#!">Convert</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Page-header end -->

    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <?php if($isExpired): ?>
                    <div class="alert alert-danger">
                        <strong>Expired!</strong> This lead expired on:
                        <b><?php echo e($click->expiryDate()->format('d M, Y h:i A')); ?></b>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header">
                        <h5><?php echo e($click->product->title); ?></h5>
                        <p class="text-muted m-b-0">
                            Lead ID: <?php echo e($click->lead_id); ?> <br>
                            Expiry Date:
                            <b><?php echo e($click->expiryDate()->format('d M, Y h:i A')); ?></b>
                        </p>
                    </div>

                    <div class="card-block">

                        <h5 class="m-b-20">Complete Levels</h5>

                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card p-3 mb-3 shadow-sm"
                                 style="border-left:4px solid #3f51b5; background:#fafafa">

                                <strong><?php echo e($level->level_order); ?>. <?php echo e($level->level_name); ?></strong><br>
                                <small><?php echo e($level->level_description); ?></small><br>
                                <b>₹<?php echo e($level->amount); ?></b>

                                <?php if(in_array($level->id, $completed)): ?>
                                    <span class="badge badge-success float-right mt-2">Completed</span>
                                <?php else: ?>

                                    <?php if($isExpired): ?>
                                        <span class="badge badge-danger float-right mt-2">Expired</span>
                                    <?php else: ?>
                                        <form method="POST"
                                              action="<?php echo e(route('admins.affiliate.clicks.level.complete', $click->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="level_id" value="<?php echo e($level->id); ?>">
                                            <button class="btn btn-primary btn-sm float-right mt-2">
                                                Mark Complete
                                            </button>
                                        </form>
                                    <?php endif; ?>

                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <hr class="mt-4 mb-4">

                        <?php if(!$isExpired): ?>
                            <form method="POST"
                                  action="<?php echo e(route('admins.affiliate.clicks.final.approve', $click->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-success btn-lg btn-block">
                                    Final Approve & Release Earnings
                                </button>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-danger text-center">
                                Cannot approve expired lead.
                            </div>
                        <?php endif; ?>

                    </div>
                </div>

            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/clicks/convert.blade.php ENDPATH**/ ?>