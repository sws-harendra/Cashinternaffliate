

<?php $__env->startPush('title'); ?>
    <title>Recruiters | <?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="pcoded-content">

    <!-- Page-header -->
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Recruiters</h5>
                        <p class="m-b-0">Manage all recruiters</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('admins.dashboard')); ?>">
                                <i class="fa fa-home"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item">Recruiters</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('backend.admins.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="card">
        <div class="card-block table-responsive">

            <table class="table table-hover">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Recruiter</th>
                    <th>Company</th>
                    <th>Verification</th>
                    <th>Account Status</th>
                    <th>Action</th>
                </tr>
                </thead>

                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recruiters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($r->id); ?></td>

                        <td>
                            <strong><?php echo e($r->name); ?></strong><br>
                            <small><?php echo e($r->email); ?></small><br>
                            <small><?php echo e($r->mobile); ?></small>
                        </td>

                        <td>
                            <?php echo e($r->profile->industry ?? 'N/A'); ?><br>
                            <small>
                                <?php echo e($r->profile->company_size ?? ''); ?>

                            </small>
                        </td>

                        <td>
                            <?php if(!$r->verification): ?>
                                <span class="badge badge-secondary">Not Uploaded</span>
                            <?php elseif($r->verification->status === 'pending'): ?>
                                <span class="badge badge-warning">Pending</span>
                            <?php elseif($r->verification->status === 'approved'): ?>
                                <span class="badge badge-success">Approved</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Rejected</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if($r->is_active): ?>
                                <span class="badge badge-success">Active</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Inactive</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <a href="<?php echo e(route('admins.recruiters.show',$r->id)); ?>"
                               class="btn btn-sm btn-primary">
                                View
                            </a>

                            <form method="POST"
                                  action="<?php echo e(route('admins.recruiters.toggle',$r->id)); ?>"
                                  class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-sm
                                    <?php echo e($r->is_active ? 'btn-danger' : 'btn-success'); ?>">
                                    <?php echo e($r->is_active ? 'Deactivate' : 'Activate'); ?>

                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted">
                            No recruiters found.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>

            <?php echo e($recruiters->links()); ?>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admins.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\bipin\Desktop\cashaffiliate\cashintern\resources\views/backend/admins/pages/recruiters/index.blade.php ENDPATH**/ ?>