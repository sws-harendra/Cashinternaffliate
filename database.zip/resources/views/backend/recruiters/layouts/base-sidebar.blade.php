  <nav class="pcoded-navbar">
      <div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>
      <div class="pcoded-inner-navbar main-menu">
          <div class="">
              <div class="main-menu-header">
                  <img class="img-80 img-radius" src="{{ asset(auth('recruiter')->user()->profile->logo ?? 'backend/assets/images/avatar-4.jpg') }}" alt="User-Profile-Image">
                  <div class="user-details">
                      <span id="more-details">Recruiter<i class="fa fa-caret-down"></i></span>
                  </div>
              </div>

              <div class="main-menu-content">
                  <ul>
                      <li class="more-details">
                          <a href="{{ route('recruiters.profile.edit') }}"><i class="ti-user"></i>View Profile</a>
                          {{-- <a href="#!"><i class="ti-settings"></i>Settings</a> --}}
                          <a href="{{ route('recruiters.logout') }}"><i class="ti-layout-sidebar-left"></i>Logout</a>
                      </li>
                  </ul>
              </div>
          </div>

          <div class="pcoded-navigation-label" data-i18n="nav.category.navigation">Layout</div>
          <ul class="pcoded-item pcoded-left-item">
              <li class="{{ request()->routeIs('recruiters.dashboard') ? 'active' : '' }}">
                  <a href="{{ route('recruiters.dashboard') }}" class="waves-effect waves-dark">
                      <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                      <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                      <span class="pcoded-mcaret"></span>
                  </a>
              </li>
              <li class="{{ request()->routeIs('recruiters.profile.edit') ? 'active' : '' }}">
                  <a href="{{ route('recruiters.profile.edit') }}" class="waves-effect waves-dark">
                      <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                      <span class="pcoded-mtext" data-i18n="nav.dash.main">Profile</span>
                      <span class="pcoded-mcaret"></span>
                  </a>
              </li>
              <li class="{{ request()->routeIs('recruiters.verification') ? 'active' : '' }}">
                  <a href="{{ route('recruiters.verification') }}" class="waves-effect waves-dark">
                      <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                      <span class="pcoded-mtext" data-i18n="nav.dash.main">Verification</span>
                      <span class="pcoded-mcaret"></span>
                  </a>
              </li>
              <li class="{{ request()->routeIs('recruiters.jobs*') ? 'active' : '' }}">
                  <a href="{{ route('recruiters.jobs.index') }}" class="waves-effect waves-dark">
                      <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                      <span class="pcoded-mtext" data-i18n="nav.dash.main">Jobs</span>
                      <span class="pcoded-mcaret"></span>
                  </a>
              </li>
            



              {{-- <li class="pcoded-hasmenu">
                  <a href="javascript:void(0)" class="waves-effect waves-dark">
                      <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
                      <span class="pcoded-mtext" data-i18n="nav.basic-components.main">Components</span>
                      <span class="pcoded-mcaret"></span>
                  </a>
                  <ul class="pcoded-submenu">
                      <li class=" ">
                          <a href="accordion.html" class="waves-effect waves-dark">
                              <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                              <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Accordion</span>
                              <span class="pcoded-mcaret"></span>
                          </a>
                      </li>
                      <li class=" ">
                          <a href="breadcrumb.html" class="waves-effect waves-dark">
                              <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                              <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Breadcrumbs</span>
                              <span class="pcoded-mcaret"></span>
                          </a>
                      </li>
                      <li class=" ">
                          <a href="button.html" class="waves-effect waves-dark">
                              <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                              <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Button</span>
                              <span class="pcoded-mcaret"></span>
                          </a>
                      </li>
                      <li class=" ">
                          <a href="tabs.html" class="waves-effect waves-dark">
                              <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                              <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Tabs</span>
                              <span class="pcoded-mcaret"></span>
                          </a>
                      </li>
                      <li class=" ">
                          <a href="color.html" class="waves-effect waves-dark">
                              <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                              <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Color</span>
                              <span class="pcoded-mcaret"></span>
                          </a>
                      </li>
                      <li class=" ">
                          <a href="label-badge.html" class="waves-effect waves-dark">
                              <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                              <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Label Badge</span>
                              <span class="pcoded-mcaret"></span>
                          </a>
                      </li>
                      <li class=" ">
                          <a href="tooltip.html" class="waves-effect waves-dark">
                              <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                              <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Tooltip</span>
                              <span class="pcoded-mcaret"></span>
                          </a>
                      </li>
                      <li class=" ">
                          <a href="typography.html" class="waves-effect waves-dark">
                              <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                              <span class="pcoded-mtext"
                                  data-i18n="nav.basic-components.breadcrumbs">Typography</span>
                              <span class="pcoded-mcaret"></span>
                          </a>
                      </li>
                      <li class=" ">
                          <a href="notification.html" class="waves-effect waves-dark">
                              <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                              <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Notification</span>
                              <span class="pcoded-mcaret"></span>
                          </a>
                      </li>
                      <li class=" ">
                          <a href="icon-themify.html" class="waves-effect waves-dark">
                              <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                              <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Themify</span>
                              <span class="pcoded-mcaret"></span>
                          </a>
                      </li>

                  </ul>
              </li> --}}
          </ul>



      </div>
  </nav>
